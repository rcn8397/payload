Perform the following steps in Eclipse:

1. Import ExampleTestProject_v4.3.1.zip by clicking on File --> Import --> Existing Project into workspace --> Select archive file --> ExampleTestProject_v4.3.1.zip.

2. NotePad and NotePadTest should now be visible in your projects list. 

3. (If needed) Right click on the app and test project and select Android Tools --> Fix project properties.

4. Right click the test project (NotePadTest) and select Run As --> Run As Android JUnit Test.  


For Robotium tutorials:

http://code.google.com/p/robotium/wiki/RobotiumTutorials


